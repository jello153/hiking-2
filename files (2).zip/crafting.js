export class Crafting {
    constructor(inventory) {
        this.inventory = inventory;
        this.lastCrafted = null;
    }
    craftCampfire() {
        // Needs: 2 sticks + 1 rock
        if (this.inventory.has('stick', 2) && this.inventory.has('rock', 1)) {
            this.inventory.remove('stick', 2);
            this.inventory.remove('rock', 1);
            this.inventory.add('campfire');
            this.lastCrafted = 'Campfire';
            return true;
        }
        this.lastCrafted = null;
        return false;
    }
}