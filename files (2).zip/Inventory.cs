using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class InventoryItem
{
    public string itemName;
    public int quantity;
}

public class Inventory : MonoBehaviour
{
    public List<InventoryItem> items = new List<InventoryItem>();

    public void AddItem(string itemName, int qty = 1)
    {
        var item = items.Find(i => i.itemName == itemName);
        if (item != null) item.quantity += qty;
        else items.Add(new InventoryItem { itemName = itemName, quantity = qty });
    }

    public bool RemoveItem(string itemName, int qty = 1)
    {
        var item = items.Find(i => i.itemName == itemName);
        if (item != null && item.quantity >= qty)
        {
            item.quantity -= qty;
            if (item.quantity == 0) items.Remove(item);
            return true;
        }
        return false;
    }
}