import * as THREE from 'three';

export class Item {
    constructor(type, position) {
        this.type = type;
        this.position = position;
        this.picked = false;
        this.mesh = this.makeMesh();
        this.mesh.position.copy(position);
    }
    makeMesh() {
        let geometry, material;
        switch (this.type) {
            case 'stick':
                geometry = new THREE.CylinderGeometry(0.1, 0.1, 1, 8);
                material = new THREE.MeshStandardMaterial({ color: 0x8b5a2b });
                break;
            case 'rock':
                geometry = new THREE.DodecahedronGeometry(0.4);
                material = new THREE.MeshStandardMaterial({ color: 0x808080 });
                break;
            case 'berry':
                geometry = new THREE.SphereGeometry(0.2, 16, 16);
                material = new THREE.MeshStandardMaterial({ color: 0xff0000 });
                break;
        }
        return new THREE.Mesh(geometry, material);
    }
}

// Place some items in the world
export const itemsInWorld = [
    new Item('stick', new THREE.Vector3(-3, 0.5, -5)),
    new Item('stick', new THREE.Vector3(5, 0.5, 2)),
    new Item('rock', new THREE.Vector3(-6, 0.5, 6)),
    new Item('rock', new THREE.Vector3(3, 0.5, -2)),
    new Item('berry', new THREE.Vector3(1, 0.5, 7)),
    new Item('berry', new THREE.Vector3(-4, 0.5, 4)),
];