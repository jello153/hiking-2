export class Inventory {
    constructor() {
        this.items = {};
    }
    add(type) {
        if (!this.items[type]) this.items[type] = 0;
        this.items[type]++;
    }
    remove(type, count=1) {
        if (this.items[type] && this.items[type] >= count) {
            this.items[type] -= count;
            if (this.items[type] === 0) delete this.items[type];
            return true;
        }
        return false;
    }
    has(type, count=1) {
        return this.items[type] && this.items[type] >= count;
    }
    list() {
        return Object.entries(this.items).map(([type, count]) => ({ type, count }));
    }
}