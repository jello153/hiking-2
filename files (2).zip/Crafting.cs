using UnityEngine;

public class Crafting : MonoBehaviour
{
    public Inventory inventory;

    // Example: Craft Campfire (needs 2 sticks + 1 rock)
    public bool CraftCampfire()
    {
        if (inventory.RemoveItem("Stick", 2) && inventory.RemoveItem("Rock", 1))
        {
            inventory.AddItem("Campfire", 1);
            Debug.Log("Crafted Campfire!");
            return true;
        }
        Debug.Log("Missing ingredients!");
        return false;
    }
}