import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

import { generateTerrain } from './terrain.js';
import { Inventory } from './inventory.js';
import { Item, itemsInWorld } from './items.js';
import { Crafting } from './crafting.js';
import { Player } from './player.js';
import { AnimalManager } from './animals.js';
import { Weather } from './weather.js';
import { initUI, updateUI, showBackpack, hideBackpack, updateAnimalsUI } from './ui.js';
import { saveGame, loadGame } from './save.js';

// Scene, Camera, Renderer
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
camera.position.set(0, 5, 14);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

// Terrain
const terrain = generateTerrain();
scene.add(terrain);

// Lighting
const ambient = new THREE.AmbientLight(0xffffff, 0.7);
scene.add(ambient);
const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
dirLight.position.set(10, 20, 10);
scene.add(dirLight);

// Player
const player = new Player(scene);

// Inventory & Crafting
const inventory = new Inventory();
const crafting = new Crafting(inventory, player);

// Items in world
itemsInWorld.forEach(item => scene.add(item.mesh));

// Animals
const animalsManager = new AnimalManager(scene);

// Weather
const weather = new Weather();

// UI
initUI({
    inventory,
    crafting,
    player,
    weather,
    animalsManager
});

// Movement
const keys = {};
window.addEventListener('keydown', e => keys[e.key.toLowerCase()] = true);
window.addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);

function movePlayer() {
    player.move(keys);
}

// Item Pickup
function checkPickup() {
    itemsInWorld.forEach(item => {
        if (!item.picked && player.mesh.position.distanceTo(item.mesh.position) < 1) {
            inventory.add(item.type);
            item.picked = true;
            scene.remove(item.mesh);
            updateUI();
        }
    });
}

// Crafting triggers
window.addEventListener('keydown', e => {
    if (e.key.toLowerCase() === 'c') {
        if (crafting.craftCampfire()) {
            updateUI();
        }
    }
    if (e.key.toLowerCase() === 'b') {
        if (crafting.craftBackpack()) {
            updateUI();
        }
    }
    if (e.key === 'Tab') {
        if (document.getElementById('backpack').style.display === 'none') {
            showBackpack(inventory);
        } else {
            hideBackpack();
        }
        e.preventDefault();
    }
});

// Save/load buttons
document.getElementById('saveBtn').onclick = () => {
    saveGame({ inventory, player });
    updateUI();
};
document.getElementById('loadBtn').onclick = () => {
    loadGame({ inventory, player });
    updateUI();
};

// Backpack button
document.getElementById('backpackBtn').onclick = () => {
    if (document.getElementById('backpack').style.display === 'none') {
        showBackpack(inventory);
    } else {
        hideBackpack();
    }
};

// Animation loop
function animate() {
    requestAnimationFrame(animate);
    movePlayer();
    player.update(); // stamina, health
    animalsManager.update(player.mesh.position);
    weather.update();
    checkPickup();
    updateUI();
    updateAnimalsUI(animalsManager.animals);
    controls.update();
    renderer.render(scene, camera);
}
animate();