import * as THREE from 'three';

export function generateTerrain() {
    const size = 50;
    const segments = 64;
    const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
    geometry.rotateX(-Math.PI / 2);

    // Simple hills
    for (let i = 0; i < geometry.attributes.position.count; i++) {
        const pos = geometry.attributes.position;
        const x = pos.getX(i);
        const z = pos.getZ(i);
        const y = Math.sin(x/5) * Math.cos(z/5) * 2 + Math.random() * 0.3;
        pos.setY(i, y);
    }

    const material = new THREE.MeshStandardMaterial({ 
        color: 0x228B22,
        flatShading: true,
        side: THREE.DoubleSide
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.receiveShadow = true;
    return mesh;
}