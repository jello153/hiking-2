using UnityEngine;

public class PickupItem : MonoBehaviour
{
    public string itemName;

    void OnTriggerEnter(Collider other)
    {
        var inv = other.GetComponent<Inventory>();
        if (inv != null)
        {
            inv.AddItem(itemName, 1);
            Destroy(gameObject); // Remove item from world
        }
    }
}